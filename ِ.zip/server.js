const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const dbPath = process.env.DB_PATH || path.join(__dirname, "data", "orders.sqlite");

if (!ADMIN_PASSWORD || !SESSION_SECRET) {
  console.error("Set ADMIN_PASSWORD and SESSION_SECRET in your environment.");
  process.exit(1);
}
if (!process.env.NODE_ENV || process.env.NODE_ENV === "development") {
  // Helpful local setup; production should use a persistent mounted disk.
}
require("fs").mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  buyer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  product TEXT NOT NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  address TEXT NOT NULL,
  notes TEXT DEFAULT ''
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const generalLimiter = rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: "draft-7", legacyHeaders: false });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: "draft-7", legacyHeaders: false });
app.use("/api", generalLimiter);

function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sign(value) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("hex");
}
function isAdmin(req) {
  const token = req.headers.cookie?.split(";").map(s => s.trim()).find(s => s.startsWith("agh_admin="))?.slice("agh_admin=".length);
  if (!token) return false;
  const parts = decodeURIComponent(token).split(".");
  if (parts.length !== 2) return false;
  const [stamp, signature] = parts;
  if (!/^\d+$/.test(stamp)) return false;
  if (Date.now() - Number(stamp) > 12 * 60 * 60 * 1000 || Number(stamp) > Date.now()) return false;
  return safeEqual(signature, sign(stamp));
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(401).json({ error: "ابتدا وارد پنل مدیر شوید." });
  next();
}

app.get("/api/status", (_req, res) => res.json({ ok: true, aiConfigured: Boolean(GEMINI_API_KEY) }));

app.post("/api/ai", aiLimiter, async (req, res) => {
  if (!GEMINI_API_KEY) return res.status(503).json({ error: "هوش مصنوعی هنوز به کلید Gemini متصل نشده است. مدیر سایت باید GEMINI_API_KEY را در تنظیمات سرور وارد کند." });
  const message = String(req.body?.message || "").trim().slice(0, 2500);
  if (!message) return res.status(400).json({ error: "سؤال خود را بنویسید." });
  const system = `تو دستیار فروشگاه مصالح ساختمانی آقابزرگ هستی. به زبان فارسی ساده و محترمانه جواب بده. درباره کاربرد آجر، سفال، سیمان، گچ، ماسه، شن، بلوک و برآورد اولیه مصالح کمک کن. قیمت، موجودی، زمان تحویل یا مشخصات قطعی را حدس نزن؛ برای آن‌ها پیشنهاد تماس با فروشگاه بده. برای برآورد تعداد مصالح، اگر اطلاعات کافی نیست، ابعاد دیوارها، ارتفاع، ضخامت، تعداد طبقات و بازشوها را بپرس. روشن بگو برآورد تقریبی است و نقشه و نظر متخصص اولویت دارد. شماره تماس فروشگاه 09132196990 است.`;
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: message }] }],
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 }
      }),
      signal: AbortSignal.timeout(25000)
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error:", response.status, JSON.stringify(data).slice(0, 1000));
      return res.status(502).json({ error: "پاسخ از سرویس Gemini دریافت نشد. تنظیمات کلید و محدودیت سرویس را بررسی کنید." });
    }
    const answer = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!answer) return res.status(502).json({ error: "پاسخ خالی از هوش مصنوعی دریافت شد." });
    res.json({ answer });
  } catch (err) {
    console.error("Gemini request failed:", err.message);
    res.status(502).json({ error: "اتصال به هوش مصنوعی برقرار نشد. لطفاً دوباره تلاش کنید." });
  }
});

app.post("/api/orders", (req, res) => {
  const body = req.body || {};
  const buyer_name = String(body.buyer_name || "").trim().slice(0, 100);
  const phone = String(body.phone || "").trim().slice(0, 40);
  const product = String(body.product || "").trim().slice(0, 100);
  const quantity = Number(body.quantity);
  const unit = String(body.unit || "").trim().slice(0, 30);
  const address = String(body.address || "").trim().slice(0, 500);
  const notes = String(body.notes || "").trim().slice(0, 500);
  if (!buyer_name || !phone || !product || !Number.isFinite(quantity) || quantity <= 0 || !unit || !address) {
    return res.status(400).json({ error: "لطفاً همه موارد ضروری سفارش را درست وارد کنید." });
  }
  try {
    const info = db.prepare(`INSERT INTO orders (created_at,buyer_name,phone,product,quantity,unit,address,notes)
      VALUES (?,?,?,?,?,?,?,?)`).run(new Date().toISOString(), buyer_name, phone, product, quantity, unit, address, notes);
    res.status(201).json({ ok: true, orderId: info.lastInsertRowid, message: "سفارش در پایگاه داده سایت ثبت شد." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "ثبت سفارش انجام نشد." });
  }
});

app.post("/api/admin/login", (req, res) => {
  const password = String(req.body?.password || "");
  if (!safeEqual(password, ADMIN_PASSWORD)) {
    return res.status(401).json({ error: "رمز عبور درست نیست." });
  }
  const stamp = String(Date.now());
  const token = `${stamp}.${sign(stamp)}`;
  res.setHeader("Set-Cookie", `agh_admin=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  res.json({ ok: true });
});
app.post("/api/admin/logout", (_req, res) => {
  res.setHeader("Set-Cookie", "agh_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
  res.json({ ok: true });
});
app.get("/api/admin/orders", requireAdmin, (_req, res) => {
  const orders = db.prepare("SELECT id, created_at, buyer_name, phone, product, quantity, unit, address, notes FROM orders ORDER BY id DESC LIMIT 500").all();
  res.json({ orders });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.listen(PORT, () => console.log(`Aghabozorg site listening on ${PORT}`));
